package com.easefun.polyv.commonui.modle;

import com.easefun.polyv.businesssdk.model.PolyvBaseVO;

/**
 * @author df
 * @create 2019/1/17
 * @Describe
 */
public class PolyvCustomQBean implements PolyvBaseVO{
    private int contentType;

    public int getContentType() {
        return contentType;
    }

    public void setContentType(int contentType) {
        this.contentType = contentType;
    }
}
