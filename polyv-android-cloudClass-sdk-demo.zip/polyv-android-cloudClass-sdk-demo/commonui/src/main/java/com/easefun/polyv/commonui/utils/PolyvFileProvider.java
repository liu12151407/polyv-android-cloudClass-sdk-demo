package com.easefun.polyv.commonui.utils;

import android.support.v4.content.FileProvider;

public class PolyvFileProvider extends FileProvider{
}
